﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Controle_de_Estoque
{
    public partial class F_Cadastro_Fornecedor : Form
    {
        public F_Cadastro_Fornecedor()
        {
            InitializeComponent();
        }
    }
}
