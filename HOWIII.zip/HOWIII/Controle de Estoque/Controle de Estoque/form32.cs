﻿namespace Controle_de_Estoque
{
    internal class form3
    {
    }
}