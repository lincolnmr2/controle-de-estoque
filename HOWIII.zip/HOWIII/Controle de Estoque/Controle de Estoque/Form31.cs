﻿namespace Controle_de_Estoque
{
    internal class Form3
    {
    }
}