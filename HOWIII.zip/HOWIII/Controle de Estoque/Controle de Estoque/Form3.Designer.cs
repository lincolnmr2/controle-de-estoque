﻿namespace Controle_de_Estoque
{
    partial class F_Menu_Cadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Sair = new System.Windows.Forms.Button();
            this.btn_voltar_cadastro_menu = new System.Windows.Forms.Button();
            this.btn_Cadastro_cliente = new System.Windows.Forms.Button();
            this.btn_cadastro_fornecedor = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Sair
            // 
            this.btn_Sair.Location = new System.Drawing.Point(600, 390);
            this.btn_Sair.Name = "btn_Sair";
            this.btn_Sair.Size = new System.Drawing.Size(167, 33);
            this.btn_Sair.TabIndex = 7;
            this.btn_Sair.Text = "Sair";
            this.btn_Sair.UseVisualStyleBackColor = true;
            this.btn_Sair.Click += new System.EventHandler(this.btn_Sair_Click);
            // 
            // btn_voltar_cadastro_menu
            // 
            this.btn_voltar_cadastro_menu.Location = new System.Drawing.Point(47, 390);
            this.btn_voltar_cadastro_menu.Name = "btn_voltar_cadastro_menu";
            this.btn_voltar_cadastro_menu.Size = new System.Drawing.Size(167, 33);
            this.btn_voltar_cadastro_menu.TabIndex = 8;
            this.btn_voltar_cadastro_menu.Text = "Voltar";
            this.btn_voltar_cadastro_menu.UseVisualStyleBackColor = true;
            this.btn_voltar_cadastro_menu.Click += new System.EventHandler(this.btn_voltar_cadastro_menu_Click);
            // 
            // btn_Cadastro_cliente
            // 
            this.btn_Cadastro_cliente.Location = new System.Drawing.Point(313, 45);
            this.btn_Cadastro_cliente.Name = "btn_Cadastro_cliente";
            this.btn_Cadastro_cliente.Size = new System.Drawing.Size(174, 55);
            this.btn_Cadastro_cliente.TabIndex = 9;
            this.btn_Cadastro_cliente.Text = "Cliente";
            this.btn_Cadastro_cliente.UseVisualStyleBackColor = true;
            // 
            // btn_cadastro_fornecedor
            // 
            this.btn_cadastro_fornecedor.Location = new System.Drawing.Point(47, 45);
            this.btn_cadastro_fornecedor.Name = "btn_cadastro_fornecedor";
            this.btn_cadastro_fornecedor.Size = new System.Drawing.Size(174, 55);
            this.btn_cadastro_fornecedor.TabIndex = 10;
            this.btn_cadastro_fornecedor.Text = "Fornecedor";
            this.btn_cadastro_fornecedor.UseVisualStyleBackColor = true;
            this.btn_cadastro_fornecedor.Click += new System.EventHandler(this.btn_cadastro_fornecedor_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(47, 197);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(174, 55);
            this.button2.TabIndex = 11;
            this.button2.Text = "Produto";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(313, 198);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(174, 55);
            this.button3.TabIndex = 12;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // F_Menu_Cadastro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btn_cadastro_fornecedor);
            this.Controls.Add(this.btn_Cadastro_cliente);
            this.Controls.Add(this.btn_voltar_cadastro_menu);
            this.Controls.Add(this.btn_Sair);
            this.Name = "F_Menu_Cadastro";
            this.Text = "Cadastro";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Sair;
        private System.Windows.Forms.Button btn_voltar_cadastro_menu;
        private System.Windows.Forms.Button btn_Cadastro_cliente;
        private System.Windows.Forms.Button btn_cadastro_fornecedor;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}